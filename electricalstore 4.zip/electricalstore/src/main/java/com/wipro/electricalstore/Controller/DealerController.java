package com.wipro.electricalstore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.electricalstore.entity.Dealer;
import com.wipro.electricalstore.serviceImpl.DealerServiceImpl;

@RestController
@RequestMapping("/api/dealer")
public class DealerController {
	
	@Autowired
	private DealerServiceImpl dealerService;
	
	@PostMapping
	public ResponseEntity<Dealer> registerDealer(@RequestBody Dealer dealer){
		Dealer dealer1 = dealerService.registerDealer(dealer);
		return new ResponseEntity<Dealer>(dealer1,HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<Dealer>> getAllDealers(){
		List<Dealer> dealer = dealerService.getAllDealers();
		return new ResponseEntity<List<Dealer>>(dealer,HttpStatus.OK);
	}
	
	@GetMapping("/{stateName}/{cityName}")
	public ResponseEntity<List<Dealer>> getDealerByStateAndCity(@PathVariable String stateName,
			@PathVariable String cityName){
		
		List<Dealer> dealers = dealerService.getDealerByStateAndCity(stateName, cityName);
		return new ResponseEntity<List<Dealer>>(dealers,HttpStatus.OK);
		
	}

}
