package com.wipro.electricalstore.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.State;
import com.wipro.electricalstore.exception.StateNotFoundException;
import com.wipro.electricalstore.repository.StateRepository;
import com.wipro.electricalstore.service.StateService;

@Service
public class StateServiceImpl implements StateService{
	
	@Autowired
	private StateRepository stateRepository;

	@Override
	public State addState(State state) {
		// TODO Auto-generated method stub
		return stateRepository.save(state);
	}

	@Override
	public List<State> getAllStates() {
		// TODO Auto-generated method stub
		return stateRepository.findAll();
	}

	@Override
	public State getState(String stateName) {
		// TODO Auto-generated method stub
		Optional<State> state = Optional.ofNullable(stateRepository.findByStateName(stateName));
		State state1 = null;
			
		
		if(state.isPresent()) {
			state1 = state.get();
		}
		else {
			throw new StateNotFoundException(stateName);
		}
		return state1;
	}

	@Override
	public State findStateById(Long id) {
		// TODO Auto-generated method stub
		Optional<State> state = stateRepository.findById(id);
		State state1 = null;
		if(state.isPresent()) {
			state1 = state.get();
		}
		else {
			throw new StateNotFoundException(id);
		}
		return state1;
		
		
	}

	@Override
	public State updateState(Long id, State state) {
		// TODO Auto-generated method stub
		Optional<State> s1 = stateRepository.findById(id);
		if(s1.isPresent()) {
			s1.get().setStateName(state.getStateName());
		}
		else {
			throw new StateNotFoundException(state.getStateName());
		}
		
		return stateRepository.save(s1.get());
	}

	@Override
	public void deleteStudent(Long id) {
		// TODO Auto-generated method stub
		Optional<State> s1 = stateRepository.findById(id);
		if(s1.isPresent()) {
			stateRepository.deleteById(id);
		}
		
	}

	


	

	
	


	

	


}
