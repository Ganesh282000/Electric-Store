package com.wipro.electricalstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.City;
import com.wipro.electricalstore.entity.Dealer;
import com.wipro.electricalstore.entity.State;

@Service
public interface DealerService {
	
	public Dealer registerDealer(Dealer dealer);
	
	public List<Dealer> getDealerByStateAndCity(String stateName, String cityName);
	public List<Dealer> getAllDealers();

}
