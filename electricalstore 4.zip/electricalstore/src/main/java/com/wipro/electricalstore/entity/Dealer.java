package com.wipro.electricalstore.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Dealer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long dealerId;
	
	private String dealerName;
	
	private Long phoneNumber;
	
	private String address;
	
	@ManyToOne
	@JoinColumn(name="state_id")
	private State state;
	
	@ManyToOne
	@JoinColumn(name="city_id")
	private City city;

	@Override
	public String toString() {
		return "Dealer [dealerId=" + dealerId + ", dealerName=" + dealerName + ", phoneNumber=" + phoneNumber
				+ ", address=" + address + ", state=" + state + ", city=" + city + "]";
	}

	public Long getDealerId() {
		return dealerId;
	}

	public void setDealerId(Long dealerId) {
		this.dealerId = dealerId;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	public Dealer() {
		super();
	}

	public Dealer(Long dealerId, String dealerName, Long phoneNumber, String address, State state, City city) {
		super();
		this.dealerId = dealerId;
		this.dealerName = dealerName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.state = state;
		this.city = city;
	}
	

}
