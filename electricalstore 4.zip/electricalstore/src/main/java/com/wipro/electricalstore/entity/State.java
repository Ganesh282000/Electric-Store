package com.wipro.electricalstore.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class State {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long stateId;
	
	private String stateName;

	public State() {
		super();
	}

	public State(Long stateId, String stateName) {
		super();
		this.stateId = stateId;
		this.stateName = stateName;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	@Override
	public String toString() {
		return "State [stateId=" + stateId + ", stateName=" + stateName + "]";
	}
	
	

}
