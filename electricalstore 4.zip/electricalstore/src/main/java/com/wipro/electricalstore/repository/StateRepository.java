package com.wipro.electricalstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.electricalstore.entity.State;

public interface StateRepository extends JpaRepository<State,Long>{
	
	public State findByStateName(String stateName) ;
	

}
