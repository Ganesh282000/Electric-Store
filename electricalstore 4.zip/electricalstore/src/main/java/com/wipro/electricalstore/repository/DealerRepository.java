package com.wipro.electricalstore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.electricalstore.entity.City;
import com.wipro.electricalstore.entity.Dealer;
import com.wipro.electricalstore.entity.State;

public interface DealerRepository extends JpaRepository<Dealer,Long> {
	
	public List<Dealer> findByStateAndCity(State state, City city);

}
