package com.wipro.electricalstore.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;

@Entity
public class ProductCategory {
	
	@Id
	
	private String productCategoryId;
	
	private String productCategoryName;

	public ProductCategory() {
		super();
	}
    private static int a=1;
	
	@PrePersist
	    public void generateProductId() {
	        this.productCategoryId = "PRC_" + String.format("%03d", a++);
	  }

	public ProductCategory(String productCategoryId, String productCategoryName) {
		super();
		this.productCategoryId = productCategoryId;
		this.productCategoryName = productCategoryName;
	}

	public String getProductCategoryId() {
		return productCategoryId;
	}

	public void setProductCategoryId(String productCategoryId) {
		this.productCategoryId = productCategoryId;
	}

	public String getProductCategoryName() {
		return productCategoryName;
	}

	public void setProductCategoryName(String productCategoryName) {
		this.productCategoryName = productCategoryName;
	}
	
	
	
	
	
	

}
