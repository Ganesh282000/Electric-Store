package com.wipro.electricalstore.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.City;
import com.wipro.electricalstore.exception.CityNotFoundException;
import com.wipro.electricalstore.repository.CityRepository;
import com.wipro.electricalstore.service.CityService;

@Service
public class CityServiceImpl implements CityService{
	
	@Autowired
	private CityRepository cityRepository;

	@Override
	public City addCity(City city) {
		// TODO Auto-generated method stub
		return cityRepository.save(city);
	}

	@Override
	public City getCity(String cityName) {
		// TODO Auto-generated method stub
		Optional <City> city = Optional.ofNullable(cityRepository.findByCityName(cityName));
		City city1=null;
		if(city.isPresent()) {
			city1 = city.get();
		}
		else {
			throw new CityNotFoundException(cityName);
		}
		return city1;
	}
	
	@Override
	public List<City> getAllCities() {
		return cityRepository.findAll();
	}

}
