package com.wipro.electricalstore.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.ProductCategory;
import com.wipro.electricalstore.repository.ProductCategoryRepository;
import com.wipro.electricalstore.service.ProductCategoryService;

@Service
public class ProductCategoryServiceImpl implements ProductCategoryService {
	
	@Autowired
	private ProductCategoryRepository productCategoryRepository;

	@Override
	public ProductCategory addProductCategory(ProductCategory productCategory) {
		// TODO Auto-generated method stub
		return productCategoryRepository.save(productCategory);
	}

	@Override
	public ProductCategory getProductCategoryByProductCategoryName(String productCategoryName) {
		// TODO Auto-generated method stub
		return productCategoryRepository.findByProductCategoryName(productCategoryName);
	}

	@Override
	public List<ProductCategory> getAllProductCategories() {
		// TODO Auto-generated method stub
		return productCategoryRepository.findAll();
	}

}
