package com.wipro.electricalstore.exception;

public class CityNotFoundException extends RuntimeException{
	
	String message;
	Long Id;
	public CityNotFoundException() {
		super();
	}
	public CityNotFoundException(String message) {
		super();
		this.message = message;
	}
	@Override
	public String toString() {
		return "CityNotFoundException"+message;
	}
	
	

}
