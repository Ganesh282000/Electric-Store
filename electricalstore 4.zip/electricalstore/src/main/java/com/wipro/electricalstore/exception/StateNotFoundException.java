package com.wipro.electricalstore.exception;

public class StateNotFoundException extends RuntimeException{
	
	String message;
	Long Id;
	
	
	public StateNotFoundException(Long id) {
		super();
		Id = id;
	}


	public StateNotFoundException() {
		super();
	}


	public StateNotFoundException(String message) {
		super();
		this.message = message;
	}
	
	public String toString() {
		
		return "State Not found"+message;
	}

}
