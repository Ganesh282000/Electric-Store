package com.wipro.electricalstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.electricalstore.entity.ProductCategory;

public interface ProductCategoryRepository extends JpaRepository<ProductCategory,Long> {
	public ProductCategory findByProductCategoryName(String productCategoryName);

}
