package com.wipro.electricalstore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.electricalstore.entity.City;
import com.wipro.electricalstore.service.CityService;

@RestController
@RequestMapping("/api/city")
public class CityController {
	
	@Autowired
	CityService cityService;
	
	@PostMapping
	public ResponseEntity<City> addCity(@RequestBody City city){
		
		City c1 = cityService.addCity(city);
		return new ResponseEntity<City>(c1,HttpStatus.CREATED);
	}
	
	@GetMapping("{cityName}")
	public ResponseEntity<City> getCityByCityName(@PathVariable String cityName) {
		City city1 = cityService.getCity(cityName);
		return new ResponseEntity<City>(city1, HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<City>> getAllCities() {
		List<City> city1 = cityService.getAllCities();
		return new ResponseEntity<List<City>>(city1, HttpStatus.OK);
	}
	

}
