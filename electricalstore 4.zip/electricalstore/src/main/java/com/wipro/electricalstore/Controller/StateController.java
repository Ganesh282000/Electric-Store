package com.wipro.electricalstore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.electricalstore.entity.State;
import com.wipro.electricalstore.repository.StateRepository;
import com.wipro.electricalstore.service.StateService;

@RestController
@RequestMapping("/api/state")
public class StateController {
	
	@Autowired
	StateService stateService;
	
	@Autowired
	private StateRepository stateRepository;
	
	@PostMapping
	public ResponseEntity<State> addState(@RequestBody State state){
		
		State s1 = stateService.addState(state);
		return new ResponseEntity<State>(s1,HttpStatus.CREATED);
		
	}
	@GetMapping
	public ResponseEntity<List<State>> getAllStates(){
		
		List<State> state1 = stateService.getAllStates();
		return new ResponseEntity<List<State>>(state1,HttpStatus.OK);
	}
	
	@GetMapping("{stateName}")
	public ResponseEntity<State> getStateByStateName(@PathVariable String stateName){
		
		State state1 = stateService.getState(stateName);
		return new ResponseEntity<State>(state1,HttpStatus.OK);
		
	}
	
	@GetMapping("/states/{id}")
	public ResponseEntity<State> getStateById(@PathVariable Long id){
		
		State s1 = stateService.findStateById(id);
		return new ResponseEntity<State>(s1,HttpStatus.OK);
	}
	
	@PutMapping("/states/{id}")
	public ResponseEntity<State> updateState(@PathVariable Long id ,@RequestBody State state){
		
		State s1 = stateService.updateState(id, state);
		return new ResponseEntity<State>(s1,HttpStatus.OK);
		
	}
	@DeleteMapping("/states/{id}")
	public ResponseEntity<Void> deleteStudent(@PathVariable Long id){
		
		stateService.deleteStudent(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
	}
	
	
	



}
