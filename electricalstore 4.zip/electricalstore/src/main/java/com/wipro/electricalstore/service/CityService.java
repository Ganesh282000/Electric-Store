package com.wipro.electricalstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.City;

@Service
public interface CityService {
	
	public City addCity(City city);
	
	public City getCity(String cityName);
	
	public List<City> getAllCities();

}
