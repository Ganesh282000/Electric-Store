package com.wipro.electricalstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.Product;

@Service
public interface ProductService {
	
	public Product addProduct(Product product);
	public List<Product> getProductByDealerName(String dealerName);
	
	public List<Product> getAllProducts();
	
	

}
