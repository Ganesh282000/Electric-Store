package com.wipro.electricalstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.electricalstore.entity.City;

public interface CityRepository extends JpaRepository<City,Long>{
	
	public City findByCityName(String cityName);

}
