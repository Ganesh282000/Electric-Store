package com.wipro.electricalstore.entity;

import org.hibernate.annotations.Comment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class ErrorResponse {

	private int status;
	private String errorMessage;
	private HttpStatus httpstatus;

	public ErrorResponse() {
		super();
	}

	public ErrorResponse(int status, String errorMessage, HttpStatus httpstatus) {
		super();
		this.status = status;
		this.errorMessage = errorMessage;
		this.httpstatus = httpstatus;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public HttpStatus getHttpstatus() {
		return httpstatus;
	}

	public void setHttpstatus(HttpStatus httpstatus) {
		this.httpstatus = httpstatus;
	}

}
