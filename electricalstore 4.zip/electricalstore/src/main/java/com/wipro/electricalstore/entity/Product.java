package com.wipro.electricalstore.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PrePersist;

@Entity
public class Product {
	
	@Id
	private String productId;

	
	private String productName;
	
	private int price;
	
	private int quantity;
	
	@ManyToOne
	@JoinColumn(name = "product_category_id")
	private ProductCategory productCategory;

	@ManyToOne
	@JoinColumn(name = "dealer_id")
	private Dealer dealer;

	public Product() {
		super();
	}
    private static int a=1;
	
	@PrePersist
	    public void generateProductId() {
	        this.productId = "PR_" + String.format("%03d", a++);
	  }

	public Product(String productId, String productName, int price, int quantity, ProductCategory productCategory,
			Dealer dealer) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.quantity = quantity;
		this.productCategory = productCategory;
		this.dealer = dealer;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public ProductCategory getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}

	public Dealer getDealer() {
		return dealer;
	}

	public void setDealer(Dealer dealer) {
		this.dealer = dealer;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price + ", quantity="
				+ quantity + ", productCategory=" + productCategory + ", dealer=" + dealer + "]";
	}
	
	

}
