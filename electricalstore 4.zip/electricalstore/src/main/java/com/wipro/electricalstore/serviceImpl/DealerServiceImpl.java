package com.wipro.electricalstore.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.City;
import com.wipro.electricalstore.entity.Dealer;
import com.wipro.electricalstore.entity.State;
import com.wipro.electricalstore.exception.CityNotFoundException;
import com.wipro.electricalstore.exception.StateNotFoundException;
import com.wipro.electricalstore.repository.CityRepository;
import com.wipro.electricalstore.repository.DealerRepository;
import com.wipro.electricalstore.repository.StateRepository;
import com.wipro.electricalstore.service.DealerService;

@Service
public class DealerServiceImpl implements DealerService{
	
	@Autowired
	private DealerRepository dealerRepository;
	
	@Autowired
	private StateRepository stateRepository;
	
	@Autowired
	private CityRepository cityRepository;

	@Override
	public Dealer registerDealer(Dealer dealer) {
		// TODO Auto-generated method stub
		return dealerRepository.save(dealer);
	}

	
	

	@Override
	public List<Dealer> getDealerByStateAndCity(String stateName, String cityName) {
		// TODO Auto-generated method stub
		Optional<State> state = Optional.ofNullable(stateRepository.findByStateName(stateName));
		State state1 = null;
		if(state.isPresent()) {
			state1=state.get();
		}
		else {
			throw new StateNotFoundException(stateName);
		}
		Optional<City> city = Optional.ofNullable(cityRepository.findByCityName(cityName));
		City city1 = null;
		if(city.isPresent()) {
			city1 = city.get();
		}
		else {
			throw new CityNotFoundException(cityName);
		}
		return dealerRepository.findByStateAndCity(state1, city1);
		//return null;
	}




	@Override
	public List<Dealer> getAllDealers() {
		// TODO Auto-generated method stub
		return dealerRepository.findAll();
	}

}
