package com.wipro.electricalstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricalstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricalstoreApplication.class, args);
	}

}
