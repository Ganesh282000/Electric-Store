package com.wipro.electricalstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.State;

@Service
public interface StateService {
	
	public State addState(State state);
	
	public List<State> getAllStates();
	
	public State findStateById(Long id);
	
	public State updateState(Long id,State state);
	
	public void deleteStudent(Long id);
	
	
	

	
	
	

	
	public State getState(String stateName);
	
	

}
