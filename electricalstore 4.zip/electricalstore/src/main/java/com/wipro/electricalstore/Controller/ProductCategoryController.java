package com.wipro.electricalstore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.electricalstore.entity.ProductCategory;
import com.wipro.electricalstore.service.ProductCategoryService;

@RestController
@RequestMapping("/api/productcategory")
public class ProductCategoryController {
	
	@Autowired
	ProductCategoryService productCategoryService;
	
	@PostMapping
	public ResponseEntity<ProductCategory> addProductCategory(@RequestBody ProductCategory productCategory){
		ProductCategory p1 = productCategoryService.addProductCategory(productCategory);
		return new ResponseEntity<ProductCategory>(p1,HttpStatus.CREATED);
		
	}
	
	@GetMapping
	public ResponseEntity<List<ProductCategory>> getAllProductCategories(){
		
		List<ProductCategory> p1 = productCategoryService.getAllProductCategories();
		return new ResponseEntity<List<ProductCategory>>(p1,HttpStatus.OK);
		
	}
	
	@GetMapping("/{productCategoryName}")
	public ResponseEntity<ProductCategory> getProductCategoryByProductCategoryName(
			@PathVariable String productCategoryName) {
		ProductCategory productCategory1 = productCategoryService
				.getProductCategoryByProductCategoryName(productCategoryName);
		return new ResponseEntity<ProductCategory>(productCategory1, HttpStatus.OK);
	}

}
