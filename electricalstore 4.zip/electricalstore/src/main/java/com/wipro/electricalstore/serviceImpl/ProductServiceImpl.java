package com.wipro.electricalstore.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.Product;
import com.wipro.electricalstore.repository.ProductRepository;
import com.wipro.electricalstore.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository productRepository;

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public List<Product> getProductByDealerName(String dealerName) {
		// TODO Auto-generated method stub
		List<Product> lop = productRepository.findAll();
		System.out.println(lop);
		List<Product> productsByDealerName = new ArrayList<>();
		for (Product product : lop) {
			if (product.getDealer().getDealerName().equals(dealerName)) {
				productsByDealerName.add(product);
			}
		}
		return productsByDealerName;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

}
