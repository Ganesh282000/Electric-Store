package com.wipro.electricalstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wipro.electricalstore.entity.ProductCategory;

@Service
public interface ProductCategoryService {
	
	public ProductCategory addProductCategory(ProductCategory productCategory);
	public ProductCategory getProductCategoryByProductCategoryName(String productCategoryName);
	public List<ProductCategory> getAllProductCategories();

}
