package com.wipro.electricalstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectricalstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
